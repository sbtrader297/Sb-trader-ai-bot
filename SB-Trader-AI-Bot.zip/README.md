# SB Trader AI Bot
Basic Telegram bot using Groq.
