import os
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
from groq import Groq

load_dotenv()
client=Groq(api_key=os.getenv("GROQ_API_KEY"))
BOT_TOKEN=os.getenv("BOT_TOKEN")

async def start(update:Update,context:ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Welcome to SB Trader AI Bot")

async def signal(update:Update,context:ContextTypes.DEFAULT_TYPE):
    r=client.chat.completions.create(model="llama-3.1-8b-instant",messages=[{"role":"user","content":"Provide a general trading analysis with a risk warning. Do not guarantee profit."}])
    await update.message.reply_text(r.choices[0].message.content)

app=Application.builder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start",start))
app.add_handler(CommandHandler("signal",signal))
app.run_polling()
